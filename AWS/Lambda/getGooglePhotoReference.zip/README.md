The .zip file in which this file and accompanying `getGooglePhotoReferece.js` is in, is used to upload the Lambda function through the Node.js `aws-sdk`.

This .zip file was created manually with a tool such as the `zip` command in a Unix-like OS, executing: `zip ./getGooglePhotoReference.zip getGooglePhotoReference.js README.md`. 

If `getGooglePhotoReference.js` is modified in any way this .zip file must be regenerated before attempting to execute `npm run setup` again, so that the changes take effect in AWS Lambda. 